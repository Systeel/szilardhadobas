This tool is a bitmap based interactive selection set, an easy way to create a selection panel for your rig or just anything which is not visible but you want to pick. 
Check out tutorial here: https://youtu.be/phplMS7mp8E

The script needs WerwackFX's XML library to run. 
If you don't have it, you need to put WkXmlLibrary.ms to 3dsmax/scripts/startup folder.
